# Importar as bibliotecas
import streamlit as st
import ajuda, analise, graficos
from streamlit_option_menu import option_menu
from session_state import SessionState

# Configuração da página
st.set_page_config(page_title='Previsão de Vendas', page_icon='📊', layout='wide')

# Inicializa o estado da sessão
session_state = SessionState.get(df=None)

# Menu de navegação
with st.sidebar:
    escolha = option_menu(
        menu_title="Menu",
        options=["Ajuda", "Análise de dados", "Análise Gráfica"],
        icons=["question-circle-fill", "bar-chart-fill", "graph-up"],
        menu_icon="cast",
        default_index=0)

# Exibir a página correspondente
if escolha == "Ajuda":
    ajuda.mostrar()
elif escolha == "Análise de dados":
    analise.mostrar(session_state)
elif escolha == "Análise Gráfica":
    graficos.mostrar(session_state)