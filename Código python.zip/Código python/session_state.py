import streamlit as st

# Classe personalizada para gerenciar o estado da sessão
class SessionState:
    def __init__(self, **kwargs):
        for key, val in kwargs.items():
            setattr(self, key, val)
        if 'df' not in kwargs:
            self.df = None

    @staticmethod
    def get(**kwargs):
        session_state = st.session_state
        if not hasattr(session_state, '_session_state'):
            session_state._session_state = SessionState(**kwargs)
        return session_state._session_state