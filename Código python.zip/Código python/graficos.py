# Importar as bibliotecas necessárias
import streamlit as st
import pandas as pd
import plotly.express as px

# Função principal da página de gráficos
def mostrar(session_state):

    # Verificar se um arquivo foi carregado
    if session_state.df is None:

        # Exibir aviso para o usuário carregar o arquivo
        st.warning("👈 Favor carregar o arquivo new_retail_data.csv na página 'Análise de dados' para continuar.")

    elif session_state.df is not None:

        # Define um cabeçalho para a aplicação
        st.header('📊 Gráficos Interativos', divider='rainbow')

        df_novo = session_state.df

        # Remove dados nulos as colunas Year e Month
        df_novo = df_novo.dropna().drop(columns=['Year', 'Month']).copy()

        # Converter a coluna 'Date' para o tipo datetime
        df_novo['Date'] = pd.to_datetime(df_novo['Date']).dt.date

        # Gera os filtros para os gráficos
        st.sidebar.header('Filtros')

        # Filtro de idade
        idade_min, idade_max = int(df_novo['Age'].min()), int(df_novo['Age'].max())
        idade_selecionada = st.sidebar.slider('Selecione o Intervalo de Idade', idade_min, idade_max, (idade_min, idade_max))

        # Filtros dinâmicos
        estado = st.sidebar.multiselect('Selecione o Estado', df_novo['State'].unique())
        segmento_cliente = st.sidebar.multiselect('Selecione o Segmento de Cliente', df_novo['Customer_Segment'].unique())
        categoria_produto = st.sidebar.multiselect('Selecione a Categoria do Produto', df_novo['Product_Category'].unique())
        metodo_pagamento = st.sidebar.multiselect('Selecione o Método de Pagamento', df_novo['Payment_Method'].unique())
        metodo_envio = st.sidebar.multiselect('Selecione o Meio de Envio', df_novo['Shipping_Method'].unique())
        marca = st.sidebar.multiselect('Selecione a Marca do Produto', df_novo['Product_Brand'].unique())        

        # Aplicar filtros ao dataframe
        if segmento_cliente:
            df_filtrado = df_novo[df_novo['Customer_Segment'].isin(segmento_cliente)]
        else:
            df_filtrado = df_novo

        if categoria_produto:
            df_filtrado = df_filtrado[df_filtrado['Product_Category'].isin(categoria_produto)]

        if metodo_pagamento:
            df_filtrado = df_filtrado[df_filtrado['Payment_Method'].isin(metodo_pagamento)]
        
        if metodo_envio:
            df_filtrado = df_filtrado[df_filtrado['Shipping_Method'].isin(metodo_envio)]

        if estado:
            df_filtrado = df_filtrado[df_filtrado['State'].isin(estado)]

        if marca:
            df_filtrado = df_filtrado[df_filtrado['Product_Brand'].isin(marca)]

        df_filtrado = df_filtrado[(df_filtrado['Age'] >= idade_selecionada[0]) & (df_filtrado['Age'] <= idade_selecionada[1])]
        

        # Configurar o streamlit em 4 colunas
        col1, col2, col3 = st.columns(3)

        # Gráfico de Pizza - métodos de pagamento
        fig1 = px.pie(df_filtrado, names='Payment_Method', title='Distribuição de Métodos de Pagamento')
        col1.plotly_chart(fig1, use_container_width=True)

        # Gráfico de Pizza - categoria de produtos
        fig2 = px.pie(df_filtrado, names='Product_Category', title='Distribuição de Categoria de Produtos')
        col2.plotly_chart(fig2, use_container_width=True)

        # Gráfico de Pizza - segmento do cliente
        fig3 = px.pie(df_filtrado, names='Customer_Segment', title='Distribuição de Segmento do Cliente')
        col3.plotly_chart(fig3, use_container_width=True)

        # Configurar o streamlit em 2 colunas
        col4, col5 = st.columns(2)

        # Gráfico pizza - análise de desempenho de produtos
        fig4 = px.pie(df_filtrado, values='Total_Amount', names='Product_Category', title='Faturamento por Categoria de Produto')
        col4.plotly_chart(fig4, use_container_width=True)

        # Gráfico de Pizza - meios de envio
        fig5 = px.pie(df_filtrado, names='Shipping_Method', title='Distribuição de Métodos de Envio')
        col5.plotly_chart(fig5, use_container_width=True)

        # Gráfico de Barras - total de Compras por Estado
        st.markdown("<h3 style='text-align: center;'>Total de Compras por Estado</h3>", unsafe_allow_html=True)
        fig6 = px.bar(df_filtrado, x='State', y='Total_Purchases', color='State')
        fig6.update_xaxes(title='Estado')
        fig6.update_yaxes(title='Total de Compras')
        st.plotly_chart(fig6, use_container_width=True)

        # Histograma - idade por Gênero
        st.markdown("<h3 style='text-align: center;'>Distribuição de Idades por Gênero</h3>", unsafe_allow_html=True)
        fig7 = px.histogram(df_filtrado, x='Age', color='Gender', barmode='overlay',
                            color_discrete_map={'Male': '#1f77b4', 'Female': '#ff7f0e'})
        fig7.update_xaxes(title='Idade')
        fig7.update_yaxes(title='Contagem')
        st.plotly_chart(fig7, use_container_width=True)

        # Converter a coluna 'Date' para datetime se ainda não estiver
        if not pd.api.types.is_datetime64_any_dtype(df_filtrado['Date']):
            df_filtrado['Date'] = pd.to_datetime(df_filtrado['Date'])

        # Agrupar por mês e marca e calcular o faturamento mensal por mês e por marca
        faturamento_mensal_marca = df_filtrado.groupby([df_filtrado['Date'].dt.to_period('M'), 'Product_Brand']).agg({'Total_Amount': 'sum'}).reset_index()

        # Converter o período para string (mês) para evitar erros de serialização JSON
        faturamento_mensal_marca['Date'] = faturamento_mensal_marca['Date'].dt.strftime('%Y-%m')

        # Gráfico de Linha - Faturamento Mensal por Marca
        st.markdown("<h3 style='text-align: center;'>Faturamento Mensal por Marca</h3>", unsafe_allow_html=True)
        fig8 = px.line(faturamento_mensal_marca, x='Date', y='Total_Amount', color='Product_Brand')
        fig8.update_xaxes(title='Data')
        fig8.update_yaxes(title='Faturamento Total')
        st.plotly_chart(fig8, use_container_width=True)

        # Agrupar por marca e calcular o total de vendas
        vendas_por_marca = df_filtrado.groupby('Product_Brand')['Total_Amount'].sum().reset_index()

        # Ordenar por total de vendas (decrescente)
        vendas_por_marca = vendas_por_marca.sort_values(by='Total_Amount', ascending=False)

        # Gráfico de barras - total de vendas por marca
        st.markdown("<h3 style='text-align: center;'>Total de Vendas por Marca</h3>", unsafe_allow_html=True)
        fig9 = px.bar(vendas_por_marca, x='Product_Brand', y='Total_Amount', color='Product_Brand')
        fig9.update_xaxes(title='Marca')
        fig9.update_yaxes(title='Total de Vendas')
        st.plotly_chart(fig9, use_container_width=True)

        # Agrupar por produto e calcular o total de vendas
        produtos_mais_vendidos = df_filtrado.groupby('products')['Total_Amount'].sum().reset_index()

        # Ordenar por total de vendas (decrescente)
        produtos_mais_vendidos = produtos_mais_vendidos.sort_values(by='Total_Amount', ascending=False)

        # Gráfico de barras - produtos mais vendidos
        st.markdown("<h3 style='text-align: center;'>Produtos mais Vendidos</h3>", unsafe_allow_html=True)
        fig10 = px.bar(produtos_mais_vendidos, x='products', y='Total_Amount')
        fig10.update_xaxes(title='Produto')
        fig10.update_yaxes(title='Total de Vendas')
        st.plotly_chart(fig10, use_container_width=True)