import streamlit as st

def mostrar():
    # Exibe o campo ajuda da aplicação
    with st.expander('Sobre este app', expanded=True):
        st.markdown('**O que faz esta aplicação?**')
        st.info('Este aplicativo permite que os usuários criem um modelo de aprendizado de máquina em um fluxo de trabalho de ponta a ponta. Particularmente, isso abrange o upload da base de dados, o pré-processamento desses dados, o treinamento e a construção do modelo de aprendizado de máquina e análise pós-modelo.')

        st.markdown('**Como usar a aplicação?**')
        st.warning('👈 Para interagir com o aplicativo, use o menu lateral seguindo as indicações:\n\n'
                   '1 - Acesse a página Análise de dados;\n\n'
                   '2 - Faça o upload da base de dados, o link para download encontra-se logo abaixo;\n\n'
                   '3 - Ajuste os parâmetros do modelo usando os vários widgets\n\n')

        st.markdown('**Base de dados**')
        st.markdown('A base de dados usada nesse aplicativo é new_retail_data, segue abaixo a url para download:')
        st.code('https://www.kaggle.com/datasets/sahilprajapati143/retail-analysis-large-dataset', language='markdown')
        
        st.markdown('**Bibliotecas usadas:**')
        st.info('- Pandas - para leitura e tratamento dos dados\n\n'
                '- Scikit-learn - para construção do modelo de aprendizado de máquina\n\n'
                '- Streamlit - para interface do usuário\n\n'
                '- Sweetviz - para gerar o relatório análise exploratória de dados\n\n'
                '- Time - para manipular o tempo de execução de processos\n\n'
                '- Base64 - para download')
