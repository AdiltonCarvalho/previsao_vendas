# Importar as bibliotecas
import streamlit as st
import pandas as pd
import sweetviz as sv
import time
import streamlit.components.v1 as components
import base64
import plotly.express as px
from pycaret.classification import setup, compare_models, pull
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


# Função principal
def mostrar(session_state):
    
    # Carrega o arquivo CSV a partir do uploader na barra lateral
    uploaded_file = st.sidebar.file_uploader("Carregue o arquivo CSV", type="csv")

    # Verificar se um arquivo foi carregado e está gravado na sessão de estado
    if uploaded_file is None and session_state.df is None:
        
        # Exibir aviso para o usuário carregar o arquivo
        st.warning('👈 Use o menu ao lado para carregar o arquivo new_retail_data.csv')

    elif uploaded_file is not None:

        # Carrega o arquivo CSV em um DataFrame
        df = pd.read_csv(uploaded_file)
        
        # Armazena o dataframe na sessão
        session_state.df = df

    # Verifica se o dataframe está armazenado na sessão
    if session_state.df is not None:

        # Definir df_sessao como uma variável que armazena o dataframe da sessão
        df_sessao = session_state.df

        # Número de linhas antes da remoção dos dados nulos
        linhas_antes = df_sessao.shape[0]

        # Copia o dataframe df para o df_copia sem dados nulos e remove as colunas Year e Month
        df_copia = df_sessao.dropna().drop(columns=['Year', 'Month']).copy()

        # Número de linhas após a remoção dos dados nulos
        linhas_depois = df_copia.shape[0]

        # Calcular o percentual de redução
        reducao_percentual = ((linhas_antes - linhas_depois) / linhas_antes) * 100

        # Converter a coluna 'Date' para o tipo datetime
        df_copia['Date'] = pd.to_datetime(df_copia['Date']).dt.date

        # Define um cabeçalho para a aplicação
        st.header('🔎 Visualização da Base de Dados', divider='rainbow')

        # Informa que o tratamento de dados nulos foi executado
        st.success(f"Percentual de redução da base de dados após a remoção dos dados nulos: {reducao_percentual:.2f}%")

        # Configurar o streamlit em 4 colunas
        col = st.columns(5)

        # Mostrar métricas
        col[0].metric(label="Número de linhas", value=df_copia.shape[0], delta="")
        col[1].metric(label="Número de variáveis", value=df_copia.shape[1], delta="")

        # Conta o número de variáveis numéricas e mostra a métrica
        num_vars_numerica = df_copia.select_dtypes(include=['number']).shape[1]
        col[2].metric(label="Variáveis numéricas", value=num_vars_numerica, delta="")

        # Conta o número de variáveis categóricas e mostra a métrica
        num_vars_categorica = df_copia.select_dtypes(include=['object', 'category']).shape[1]
        col[3].metric(label="Variáveis categóricas", value=num_vars_categorica, delta="")

        # Valida se existem dados nulos no dataframe e mostra a métrica
        tem_nulo = "Sim" if df_copia.isnull().any().any() else "Não"
        col[4].metric(label="Existe valor nulo?", value=tem_nulo, delta="")

        # Exibe o DataFrame
        st.dataframe(df_copia)

        # Gera o DataFrame `dataset` excluindo a coluna 'Date' e amostrando aleatoriamente 40.000 linhas
        dataset = df_copia.drop(columns=['Date']).sample(40000).copy()

        # Configurar o experimento no PyCaret
        clf_setup = setup(data=dataset, 
                        target='Payment_Method',
                        session_id=123, 
                        normalize=True, 
                        normalize_method='zscore', 
                        transformation=True, 
                        transformation_method='quantile', 
                        fix_imbalance=True)

        # Obter os resultados do experimento
        resultado_experimento = pull()

        # Compara o modelo atual
        melhor_modelo = compare_models(fold=4, sort='AUC')

        # Obter o resultado da comparação de modelos 
        resultado_selecao = pull()

        # Define um cabeçalho para análise exploratória de dados
        st.header('📝 Análise Exploratória de Dados', divider='rainbow')

        # Inicializa a barra de progresso
        progress_bar = st.progress(0)
        progress_text = st.empty()

        # Analisando Variáveis
        for i in range(70):
            progress_text.text(f"Analisando Variáveis... ({i}%)")
            progress_bar.progress(i)
            time.sleep(0.04)
        
        # Gerando Relatório EDA
        progress_text.text(f"Gerando Relatório EDA... (70%)")
        progress_bar.progress(70)
        report = sv.analyze(df_copia)  # Gera o relatório EDA
        time.sleep(0.04) 
        
        # Salvando Relatório EDA
        for i in range(71, 100):
            progress_text.text(f"Salvando Relatório EDA... ({i}%)")
            progress_bar.progress(i)
            time.sleep(0.04)
        
        # Salva o relatório EDA
        report.show_html(filepath='EDA_Report.html', open_browser=False) 
        
        # Conclusão do processamento
        progress_bar.progress(100)
        progress_text.text("Relatório EDA gerado com sucesso!")
        
        # Abre o arquivo EDA_Report.html no modo de leitura, faz a leitura e retorna o conteúdo
        with open("EDA_Report.html", "r", encoding='utf-8') as file:
            report_html = file.read()

        # Mostra o relatório eda na aplicação
        components.html(report_html, height=800, scrolling=True)

        # Link para download
        # Codifica o conteúdo HTML em base64
        b64 = base64.b64encode(report_html.encode()).decode()

        # Cria o link HTML
        href = f'<a href="data:text/html;base64,{b64}" download="EDA_Report.html">Download do Relatório EDA</a>'
        
        # Adiciona o link de download do relatório EDA
        st.markdown(href, unsafe_allow_html=True)

        # Define um cabeçalho para análise de outliers
        st.header('🔬 Experimento de Aprendizado de Máquina', divider='rainbow')

        # configurar a aplicação em duas colunas
        col = st.columns(2)

        # Mostrar o resultado do experimento na aplicação
        col[0].table(resultado_experimento)

        # Define um cabeçalho para análise de outliers
        st.header('🤖 Treinamento de Modelos de Aprendizado de Máquina', divider='rainbow')

        # Mostrar o resultado do treinamento dos modelos
        st.table(resultado_selecao)

        # Define um cabeçalho para análise de outliers
        st.header('🏗️ Construtor de Modelo de Aprendizado de Máquina', divider='rainbow')

        # Encontrar o modelo com o maior AUC
        melhor_modelo = resultado_selecao.loc[resultado_selecao['AUC'].idxmax(), 'Model']

        # Mostra o melhor modelo selecionado na comparação 
        st.info(f'Melhor modelo selecionado: {melhor_modelo}')

        # Gera o DataFrame `dataset` excluindo a coluna 'Date' e amostrando aleatoriamente 40.000 linhas
        dataset = df_copia.drop(columns=['Date']).sample(40000).copy()

        # Codificar variáveis categóricas
        for col in dataset.select_dtypes(include=['object']).columns:
            dataset[col] = LabelEncoder().fit_transform(dataset[col])

        # Selecione suas features e a variável alvo
        X = dataset.drop(columns=['Payment_Method', 'Transaction_ID', 'Customer_ID', 'Phone'])
        y = dataset['Payment_Method']

        # Divida o conjunto de dados em treinamento e teste
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Treine o modelo ExtraTreesClassifier
        model = ExtraTreesClassifier()
        model.fit(X_train, y_train)

        # Obtenha as importâncias das variáveis
        importances = model.feature_importances_

        # Crie um dataframe para organizar as importâncias
        feature_importances = pd.DataFrame({'Feature': X.columns, 'Importance': importances})
        feature_importances = feature_importances.sort_values(by='Importance', ascending=False)

        # Plote as importâncias das variáveis usando plotly
        fig = px.bar(feature_importances, x='Importance', y='Feature', orientation='h', title='Importância das Variáveis')
        fig.update_layout(yaxis={'categoryorder':'total ascending'})

        # Exibir o gráfico no Streamlit
        st.plotly_chart(fig)